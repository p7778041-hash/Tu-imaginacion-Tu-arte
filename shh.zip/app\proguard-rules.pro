# Add project-specific ProGuard rules here.
# Keeping this file to allow release builds without errors.
