package com.tuempresa.controltvir

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var irManager: ConsumerIrManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Asegúrate de tener un botón con id 'btnApagar' en tu layout

        // Inicializar el administrador de infrarrojos
        irManager = getSystemService(Context.CONSUMER_IR_SERVICE) as ConsumerIrManager

        val btnApagar = findViewById<Button>(R.id.btnApagar)
        
        btnApagar.setOnClickListener {
            apagarTelevision()
        }
    }

    private fun apagarTelevision() {
        // 1. Verificar si el dispositivo tiene emisor IR
        if (!irManager.hasIrEmitter()) {
            Toast.makeText(this, "Este dispositivo no tiene emisor de infrarrojos", Toast.LENGTH_LONG).show()
            return
        }

        // 2. Definir la frecuencia portadora (38,000 Hz es el estándar para el 95% de las TVs)
        val frecuenciaPortadora = 38000 

        // 3. Definir el patrón de pulsos (EN MICROSEGUNDOS)
        // ¡IMPORTANTE! Este patrón es un EJEMPLO genérico (protocolo NEC). 
        // Debes reemplazarlo con el patrón exacto de tu marca de TV (ver Paso 3 abajo).
        val patronApagado = intArrayOf(
            9000, 4500,       // Encabezado (Header)
            560, 560,         // Bit 0
            560, 1690,        // Bit 1
            560, 560,         // Bit 0
            560, 1690,        // Bit 1
            // ... (Un código real tiene entre 60 y 100 números en este array)
            560               // Bit final
        )

        // 4. Transmitir la señal
        irManager.transmit(frecuenciaPortadora, patronApagado)
        
        Toast.makeText(this, "Señal de apagado enviada", Toast.LENGTH_SHORT).show()
    }
}