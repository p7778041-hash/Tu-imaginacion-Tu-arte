# Android project `shh`

Este directorio contiene un proyecto Android nativo para generar un APK.

## Requisitos

- Java JDK 17 instalado
- Android SDK instalado con herramientas de línea de comandos
- Gradle instalado en PATH o el wrapper `gradlew.bat` disponible

## Cómo compilar

1. Abre una terminal en `d:\Antigravity\shh`.
2. Ejecuta:

```cmd
build-android.cmd
```

o con PowerShell:

```powershell
.uild-android.ps1
```

Si tienes Gradle instalado, el script usará `gradle assembleDebug`. Si agregas un wrapper Gradle (`gradlew.bat`), el script lo usará automáticamente.

## Salida

El APK generado estará en:

- `d:\Antigravity\shh\app\build\outputs\apk\debug\app-debug.apk`

## Notas

- En el entorno actual no hay Android SDK instalado, por lo que no se puede generar el APK directamente aquí.
- Si necesitas una versión de BookApp para Android en lugar de este proyecto nativo, eso requiere una implementación adicional con MAUI o Android/Flutter.
