# Ejemplo conceptual en Python para enviar comando de apagado a una Smart TV
# ADVERTENCIA: Esto solo funciona si la TV ya fue emparejada previamente con este dispositivo.
import requests
import json

def apagar_tv_smart(direccion_ip_tv, token_autorizacion):
    url = f"http://{direccion_ip_tv}:8002/api/v2/remote/control" # Ejemplo basado en API de Samsung Tizen
    
    payload = {
        "method": "ms.remote.control",
        "params": {
            "Cmd": "Power",
            "DataOfCmd": "Power",
            "Option": "false",
            "TypeOfRemote": "SendRemoteKey"
        }
    }
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {token_autorizacion}" # Token obtenido tras el emparejamiento inicial con código
    }

    try:
        response = requests.post(url, json=payload, headers=headers, timeout=5)
        if response.status_code == 200:
            print("Comando de apagado enviado correctamente.")
        else:
            print(f"Error: La TV rechazó el comando. Código {response.status_code}. ¿Ya fue emparejada?")
    except requests.exceptions.RequestException as e:
        print(f"No se pudo conectar a la TV. Verifica que esté en la misma red Wi-Fi. Error: {e}")

# Uso:
# apagar_tv_smart("192.168.1.50", "tu_token_guardado_de_la_configuracion_inicial")