package com.tuempresa.controltvir

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var irManager: ConsumerIrManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        irManager = getSystemService(Context.CONSUMER_IR_SERVICE) as ConsumerIrManager

        val btnApagar = findViewById<Button>(R.id.btnApagar)
        btnApagar.setOnClickListener {
            apagarTelevision()
        }
    }

    private fun apagarTelevision() {
        if (!irManager.hasIrEmitter()) {
            Toast.makeText(this, "Este dispositivo no tiene emisor de infrarrojos", Toast.LENGTH_LONG).show()
            return
        }

        val frecuenciaPortadora = 38000
        val patronApagado = intArrayOf(
            9000, 4500,
            560, 560,
            560, 1690,
            560, 560,
            560, 1690,
            560
        )

        irManager.transmit(frecuenciaPortadora, patronApagado)
        Toast.makeText(this, "Señal de apagado enviada", Toast.LENGTH_SHORT).show()
    }
}
