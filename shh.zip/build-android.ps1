$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
if (Test-Path .\gradlew.bat) {
    .\gradlew.bat assembleDebug
} else {
    gradle assembleDebug
}
if ($LASTEXITCODE -ne 0) {
    throw 'Android build failed. Install Gradle and Android SDK, then try again.'
}
Write-Host "APK built at app\build\outputs\apk\debug\app-debug.apk"
