@echo off
cd /d "%~dp0"
if exist gradlew.bat (
    call gradlew.bat assembleDebug
) else (
    gradle assembleDebug
)
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%
echo APK built in %~dp0app\build\outputs\apk\debug\app-debug.apk
